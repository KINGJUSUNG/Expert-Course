function showList() {
	$.ajax({
		url: '../SurveyGetSurveyInfo.do',
		type: 'post', 
		success: function(data) {
			for (let i = 0; i < data.list.length; i++) {
				let sInfo = data.list[i];
				let obj = 
					$('<ul>' +
					'<li>' + sInfo.writer + '</li>' +
					'<li>' + sInfo.s_title + '</li>' +
					'<li>' + sInfo.interest_count + '</li>' +
					'<li>' + sInfo.written_date + '</li>' +
					'<li>' + sInfo.end_date + '</li>' +							
					'</ul>');
				$(obj).appendTo('.deadLineCon');
			}
		}
	});
}

$(document).ready(function() {
	showList();
});





	